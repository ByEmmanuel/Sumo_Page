# Mini Sumo Lab · Espacio reservado para el controlador.
# Todavía no hay algoritmos de control ni de combate.
# Cada guardado con cambios crea una versión inmutable.
