"""Mini-sumo v1: sensor-only combatants and an independent match referee.

Both strategies, referee rules and parameters are saved together in the history.
The robots never receive the opponent's coordinates. Only the referee observes
world positions to score ring-outs and record evidence.
"""
import json
import math
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


class Fighter:
    def __init__(self, parameters):
        self.p = parameters
        self.action = None
        self.until = 0
        self.turn = 1
        self.push_since = None

    def decide(self, now, distances, edges):
        front, left, right = distances
        fl, fr, rl, rr = [v > self.p['edge_threshold'] for v in edges]
        speed = self.p['attack_speed']
        # The edge always takes precedence over attacking or timed maneuvers.
        if (fl or fr) and (rl or rr):
            self.action = None
            return (-5, 5, 'BORDE / GIRANDO')
        if fl or fr:
            self.turn = -1 if fl else 1
            self.action, self.until = 'reverse', now + self.p['reverse_seconds']
            self.push_since = None
            return (-speed*.7, -speed*.7, 'EVITANDO BORDE')
        if rl or rr:
            self.action = None
            return (speed*.7, speed*.7, 'ALEJANDO BORDE TRASERO')
        if self.action == 'reverse':
            if now < self.until:
                return (-speed*.7, -speed*.7, 'RETROCEDIENDO')
            self.action, self.until = 'turn', now + self.p['turn_seconds']
        if self.action == 'turn':
            if now < self.until:
                return (-self.turn*7, self.turn*7, 'REORIENTANDO')
            self.action = None
        if front < self.p['detection_range']:
            if self.push_since is None:
                self.push_since = now
            if now - self.push_since > self.p['reposition_seconds']:
                self.push_since = None
                self.turn *= -1
                self.action, self.until = 'reverse', now + .18
                return (-9, -9, 'CAMBIANDO ANGULO')
            return (speed, speed, 'ATACANDO')
        self.push_since = None
        if left < self.p['detection_range']:
            self.turn = 1
            return (2, speed*.8, 'RIVAL A LA IZQUIERDA')
        if right < self.p['detection_range']:
            self.turn = -1
            return (speed*.8, 2, 'RIVAL A LA DERECHA')
        return (-self.turn*self.p['search_speed'], self.turn*self.p['search_speed'], 'BUSCANDO')


def run_fighter(role, parameters):
    from controller import Robot
    robot = Robot()
    step = int(robot.getBasicTimeStep())
    motors = [robot.getDevice(name+'_motor') for name in ('left','right')]
    for motor in motors:
        motor.setPosition(float('inf'))
        motor.setVelocity(0)
    distance_sensors = [robot.getDevice('opponent_'+name) for name in ('front','left','right')]
    edge_sensors = [robot.getDevice('edge_'+name) for name in ('front_left','front_right','rear_left','rear_right')]
    receiver = robot.getDevice('match_receiver')
    for device in distance_sensors + edge_sensors + [receiver]:
        device.enable(step)
    fighter = Fighter(parameters[role])
    stopped = False
    while robot.step(step) != -1:
        while receiver.getQueueLength():
            stopped = stopped or receiver.getString() == 'STOP'
            receiver.nextPacket()
        distances = [sensor.getValue() for sensor in distance_sensors]
        edges = [sensor.getValue() for sensor in edge_sensors]
        if stopped:
            left, right, state = 0, 0, 'COMBATE TERMINADO'
        elif robot.getTime() < parameters['match']['countdown']:
            left, right, state = 0, 0, 'LISTO'
        else:
            left, right, state = fighter.decide(robot.getTime(), distances, edges)
        for motor, velocity in zip(motors, (left,right)):
            motor.setVelocity(max(-20,min(20,velocity)))
        robot.setCustomData(json.dumps(dict(role=role,state=state,motors=[left,right],distances=distances,edges=edges)))


def node_field(node, name):
    return node.getBaseNodeField(name) if node.isProto() else node.getField(name)


def node_ids(node):
    result = {node.getId()}
    children = node_field(node,'children')
    if children:
        for i in range(children.getCount()):
            result |= node_ids(children.getMFNode(i))
    endpoint = node_field(node,'endPoint')
    if endpoint and endpoint.getSFNode():
        result |= node_ids(endpoint.getSFNode())
    return result


def ring_out(position, contacts, radius):
    # Touching the external floor loses; crossing with only a sensor does not.
    floor_touch = any(p.point[2] < .001 and math.hypot(*p.point[:2]) > radius for p in contacts)
    fully_out = math.hypot(*position[:2]) > radius + .068
    return floor_touch or fully_out


def run_referee(parameters, manifest, run_directory, test_mode):
    from controller import Supervisor
    robot = Supervisor()
    step = int(robot.getBasicTimeStep())
    nodes = [robot.getFromDef('SUMO'),robot.getFromDef('RIVAL')]
    emitter = robot.getDevice('match_emitter')
    enemy_ids = node_ids(nodes[1])
    starts = [node.getPosition()[:] for node in nodes]
    max_travel = [0.,0.]
    contact_steps = 0
    duration = parameters['match']['duration']
    countdown = parameters['match']['countdown']
    run_directory.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]
    summary = dict(id=run_id,created=datetime.now(timezone.utc).isoformat(),version_id=manifest['id'],version_hash=manifest['hash'],world_hash=manifest['world_hash'],model_hash=manifest['model_hash'],player='MS-001 · TU ROBOT · VERDE',opponent='RIVAL · ROJO',mode='test' if test_mode else 'live',rules=parameters['match'])
    robot.setLabel(0,'TU ROBOT: MS-001  |  VERDE',.03,.03,.065,0xb9f279)
    robot.setLabel(1,'RIVAL  |  ROJO',.64,.03,.065,0xff7766)
    robot.setLabel(4,f"Algoritmos v{manifest['id']:04d}  /  {manifest['hash'][:10]}",.03,.91,.04,0xbac6c6)
    robot.setLabel(5,'Victoria: tocar el suelo fuera del dohyo. Limite: 60 s.',.03,.96,.035,0xbac6c6)
    trace_path = run_directory/(run_id+'.jsonl')
    with trace_path.open('x') as trace:
        while robot.step(step) != -1:
            now = robot.getTime()
            positions = [node.getPosition()[:] for node in nodes]
            contacts = [node.getContactPoints(True) for node in nodes]
            touching = any(p.node_id in enemy_ids for p in contacts[0])
            contact_steps += int(touching)
            for i in range(2):
                max_travel[i] = max(max_travel[i], math.dist(positions[i],starts[i]))
            elapsed = max(0,now-countdown)
            robot.setLabel(2,f'INICIO EN {math.ceil(countdown-now)}' if now<countdown else f'COMBATE  |  {max(0,duration-elapsed):05.1f} s',.34,.12,.065,0xffffff)
            states = []
            for node in nodes:
                try:
                    states.append(json.loads(node_field(node,'customData').getSFString()))
                except ValueError:
                    states.append({})
            robot.setLabel(3,'MS-001: '+states[0].get('state','LISTO')+'    /    RIVAL: '+states[1].get('state','LISTO'),.03,.85,.045,0xd5dfdf)
            trace.write(json.dumps(dict(time=now,positions=positions,touching=touching,controllers=states))+'\n')
            if now<countdown:
                continue
            eliminated = [ring_out(position,points,parameters['match']['radius']) for position,points in zip(positions,contacts)]
            if any(eliminated) or elapsed>=duration:
                winner = 'draw' if all(eliminated) or not any(eliminated) else 'opponent' if eliminated[0] else 'player'
                reason = 'salida simultanea' if all(eliminated) else 'salida del dohyo' if any(eliminated) else 'limite de tiempo'
                summary.update(winner=winner,reason=reason,elapsed=elapsed,contact_seconds=contact_steps*step/1000,max_travel=max_travel,positions=positions,trace=trace_path.name)
                break
        else:
            return
    if 'winner' not in summary:
        return
    result = 'GANA TU ROBOT: MS-001' if winner=='player' else 'GANA EL RIVAL ROJO' if winner=='opponent' else 'EMPATE'
    robot.setLabel(2,result,.25,.12,.075,0xb9f279 if winner=='player' else 0xff7766 if winner=='opponent' else 0xffffff)
    robot.setLabel(3,reason.upper()+'  |  Recarga el mundo para otra pelea.',.03,.85,.045,0xffffff)
    emitter.send(b'STOP')
    for _ in range(4):
        if robot.step(step)==-1:
            break
    summary['stopped'] = all(json.loads(node_field(node,'customData').getSFString()).get('motors')==[0,0] for node in nodes)
    (run_directory/(run_id+'.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    robot.exportImage(str(run_directory/(run_id+'.png')),90)
    print('MATCH_RESULT '+json.dumps(summary,ensure_ascii=False),flush=True)
    if test_mode:
        robot.simulationQuit(0 if min(max_travel)>.04 and contact_steps>0 and summary['stopped'] else 1)
    else:
        robot.simulationSetMode(Supervisor.SIMULATION_MODE_PAUSE)
        while robot.step(step)!=-1:
            pass


def main(parameters, manifest, role, run_directory, test_mode):
    if role=='referee':
        run_referee(parameters,manifest,Path(run_directory),test_mode)
    elif role in ('player','opponent'):
        run_fighter(role,parameters)
    else:
        raise ValueError('Rol de combate desconocido.')
